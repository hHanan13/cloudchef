

<?php $__env->startSection('content'); ?>

                    <div class="tab-content"  id="myTabContentwrapper">
                        <div class="employees__dashboard tab-pane fade in active show" role="tabpanel" id="employees__dashboard">
                            <div class="dashboard__center row px-0">
                                <div class="col-12 col-xl-9">
                                    <div class="table__wrapper">
                                        <div class="dashboard__table">
                                            <div class="thead">
                                                <div class="row">
                                                    <div class="col"><?php echo app('translator')->get('lang.name'); ?></div>
                                                    <div class="col"><?php echo app('translator')->get('lang.trade name'); ?></div>
                                                    <div class="col"><?php echo app('translator')->get('lang.email'); ?></div>
                                                    <div class="col"><?php echo app('translator')->get('lang.number'); ?></div>
                                                    <div class="col"></div>
                                                    <div class="col-1"></div>
                                                </div>
                                            </div>
                                                <?php if(count($users) > 0): ?>

                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <!--row one-->
                                                        <div class="twrapper table__row">
                                                            <div class="row collapse__table">
                                                                <div class="col"><?php echo e($row->name); ?></div>
                                                                <div class="col"><?php echo e($row->store_name); ?></div>
                                                                <div class="col"><?php echo e($row->email); ?></div>
                                                                <div class="col"><?php echo e($row->phone); ?></div>
                                                                <div class="col">
                                                                    <?php if($row->contact == true): ?>         
                                                                        <span class="contacted_span active__color">contacted</span>         
                                                                    <?php else: ?>
                                                                    <a href="<?php echo e(url('admin/report/'.$row->id.'/contact')); ?>" onclick="confirm('Are you sure?') || event.stopImmediatePropagation()" ><span class="contacted_span">waiting...</span></a>      
                                                                    <?php endif; ?>    
                                                                </div>
                                                                <div class="col-1">
                                                                <div class="dropdown dashboard__dropdown">
                                                                        <button class="dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                                                            <i class="fa-solid fa-ellipsis dots__icon"></i>
                                                                        </button>
                                                                        <div class="dropdown-menu">
                                                                            <a class="dropdown-item open__report__wrapper" href="<?php echo e(url('/admin/report',$row->id)); ?>">
                                                                                <img src="<?php echo e(asset('images/report.svg')); ?>" alt="" class="dropdown__icon" width="20px" height="27px">
                                                                                <span>report</span>
                                                                            </a>
                                                                            <a class="dropdown-item" href="index.html">
                                                                                <img src="<?php echo e(asset('images/envelope.svg')); ?>" alt="" class="dropdown__icon" width="20px" height="18px">
                                                                                <span>email</span>
                                                                            </a>
                                                                            <div class="dropdown-divider"></div>
                                                                            <a class="dropdown-item delete__dashrow has__function" href="#">
                                                                                <img src="<?php echo e(asset('images/trash.svg')); ?>" alt="" class="dropdown__icon" width="18px" height="27px">
                                                                                <span>delete</span>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="collapsed__div">
                                                                <div class="row">
                                                                    <div class="col"><?php echo app('translator')->get('lang.city'); ?></div>
                                                                    <div class="col"><?php echo app('translator')->get('lang.date'); ?></div>
                                                                    <div class="col"><?php echo app('translator')->get('lang.package'); ?></div>
                                                                    <div class="col"></div>
                                                                    <div class="col"></div>
                                                                    <div class="col"></div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col"><?php echo e($row->city); ?></div>
                                                                    <div class="col"><?php echo e($row->created_at->diffForHumans()); ?></div>
                                                                    <div class="col">package name</div>
                                                                    <div class="col"></div>
                                                                    <div class="col"></div>
                                                                    <div class="col"></div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col"><?php echo app('translator')->get('lang.capital'); ?></div>
                                                                    <div class="col"><?php echo app('translator')->get('lang.experience'); ?></div>
                                                                    <div class="col"><?php echo app('translator')->get('lang.kitchen'); ?></div>
                                                                    <div class="col"></div>
                                                                    <div class="col"></div>
                                                                    <div class="col"></div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col"><?php echo e($row->capital); ?> sr</div>
                                                                    <div class="col"><?php echo e($row->experience); ?> years</div>
                                                                    <div class="col">
                                                                        <span class="mr__26 flex__icons"><img src="<?php echo e(asset('images/p1.png')); ?>" alt="" class="part__icon"> <?php echo e($row->kind); ?></span>
                                                                    </div>
                                                                    <div class="col"></div>
                                                                    <div class="col"></div>
                                                                    <div class="col"></div>
                                                                </div>
                                                                
                                                            </div>
                                                            
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php else: ?>

                                                <tr>
                                                    <td colspan="5" class="text-center">No Data Found</td>
                                                </tr>

                                                <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-xl-3">
                                    <div class="pt__30">
                                        
                                        <div class="yellow__card bk__site">
                                            <h3 class="side__title"><?php echo app('translator')->get('lang.visit website'); ?></h3>
                                            <div class="flex__end">
                                                <span class="red__num">300</span>
                                                <span><?php echo app('translator')->get('lang.client'); ?></span>
                                            </div>
                                        </div>
                                        <div class="yellow__card rg__site">
                                            <h3 class="side__title"><?php echo app('translator')->get('lang.Registered'); ?></h3>
                                            <div class="flex__end">
                                                <span class="red__num"><?php echo e(\App\Models\merchant::count()); ?></span>
                                                <span><?php echo app('translator')->get('lang.client'); ?></span>
                                            </div>
                                            <h5 class="red__title"><?php echo app('translator')->get('lang.new'); ?></h5>
                                            <div class="flex__end">
                                                <span class="grey__num"><?php echo e(\App\Models\merchant::where('status', '0')->count()); ?></span>
                                                <span><?php echo app('translator')->get('lang.client'); ?></span>
                                            </div>
                                            <h5 class="red__title"><?php echo app('translator')->get('lang.Professional'); ?></h5>
                                            <div class="flex__end">
                                                <span class="grey__num"><?php echo e(\App\Models\merchant::where('status', '1')->count()); ?></span>
                                                <span><?php echo app('translator')->get('lang.client'); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="training__dahboard tab-pane fade" role="tabpanel" id="training__dahboard">
                            <?php echo $__env->make('dashboard.training', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                        </div>
                    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cloudchef\resources\views/dashboard/home.blade.php ENDPATH**/ ?>