

<?php $__env->startSection('content'); ?>

 <!--start package section-->
 <section class="package__section">
        <div class="container package__container">
            <div class="row package__row">
            <?php if(session('message')): ?>
                                    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                    <?php endif; ?>
                <div class="col-12 col-lg-8">
                    <div class="package__wrapper">
                        <div class="packTitle">
                            <img src="<?php echo e(asset('images/wrd.png')); ?>" alt="" class="packImgThumb">
                            <span><?php echo app('translator')->get('lang.Emerging Restaurant Package'); ?></span>
                        </div>
                        <ol class="packageCont">
                            <li> <?php echo app('translator')->get('lang.Establishing the restaurant according to the target audience.'); ?></li>
                            <li> <?php echo app('translator')->get('lang.Designing the identity of the restaurant, packaging and store.'); ?></li>
                            <li> <?php echo app('translator')->get('lang.Ad design and photography of advertising content.'); ?></li>
                            <li> <?php echo app('translator')->get('lang.Menu engineering and design.'); ?></li>
                            <li> <?php echo app('translator')->get('lang.Create your online store.'); ?></li>
                            <li> <?php echo app('translator')->get('lang.Integration with multiple delivery platforms.'); ?></li>
                            <li> <?php echo app('translator')->get('lang.Ads management for your store and your account on delivery platforms.'); ?></li>
                            <li> <?php echo app('translator')->get('lang.Administrative and operational support.'); ?></li>
                            <li> <?php echo app('translator')->get('lang.operational financial'); ?></li>
                            <li> <?php echo app('translator')->get('lang.your restaurant from and to.'); ?></li>
                        </ol>
                        <div class="flexEndPack">
                            <p><?php echo app('translator')->get('lang.Launch your restaurant now and start selling now.'); ?></p>
                            <a href="<?php echo e(route('payment.create')); ?>" class="modal__btn next__btn my-0">next</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="contact__info p__absolute">
            <h3 class="contact__title"><?php echo app('translator')->get('lang.contact info'); ?></h3>
            <div class="contact__card">
                <span class="phone_icon info__icon"></span>
                <a href="#" class="info__num">0000 000 000 000</a>
            </div>
            <div class="contact__card">
                <span class="email_icon info__icon"></span>
                <a href="#" class="info__num">example@gmail.com</a>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cloudchef\resources\views/package.blade.php ENDPATH**/ ?>