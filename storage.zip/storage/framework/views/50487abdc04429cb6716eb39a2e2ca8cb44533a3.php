

<?php $__env->startSection('content'); ?>

<section class="jobs__section">
        <div class="container job__container">
            <div class="row">
                <div class="col-12 col-xl-8">
                    <ul class="nav nav-pills dash__inner__pills mb__66">
                        <li class="nav-item">
                            <a class="nav-link active" href="#curr__wrapper" data-toggle="tab">
                                <?php echo app('translator')->get('lang.current functions'); ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#coll__orders" data-toggle="tab">
                                <?php echo app('translator')->get('lang.Collaborative Training'); ?>
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content"  id="myjob__tabs">
                        <div class="curr__wrapper tab-pane fade in active show" role="tabpanel" id="curr__wrapper">
                            <form action="<?php echo e(route('jobs.store')); ?>" method="post" enctype="multipart/form-data" class="register__form jobs__from pt__70">
                            <?php echo csrf_field(); ?>
                                <div class="d__flex">
                                    <div class="col-12 col-md-6">
                                        <select class="nice-select dashboard__select" name="job_name">
                                            <option value="all" selected><?php echo app('translator')->get('lang.managing director'); ?></option>
                                            <option value="Executive Chef"><?php echo app('translator')->get('lang.Executive Chef'); ?></option>
                                            <option value="Assistant Chef"><?php echo app('translator')->get('lang.Sales Specialist'); ?></option>
                                        </select>
                                        <div class="form-group col-12">
                                            <div class="relative__group">
                                                <label for="" class="abs__label"><?php echo app('translator')->get('lang.name'); ?></label>
                                                <input type="text" placeholder="<?php echo app('translator')->get('lang.name'); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name">
                                                <!-- <span class="text-danger"> <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> -->
                                            </div> 
                                        </div>

                                        <div class="form-group col-12">
                                            <div class="relative__group">
                                                <label for="" class="abs__label"><?php echo app('translator')->get('lang.email'); ?></label>
                                                <input type="email" placeholder="<?php echo app('translator')->get('lang.email'); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email">
                                                <!-- <span class="text-danger"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> -->
                                            </div> 
                                        </div>

                                        <div class="form-group col-12">
                                            <div class="relative__group">
                                                <label for="" class="abs__label"><?php echo app('translator')->get('lang.number'); ?></label>
                                                <input type="phone" placeholder="<?php echo app('translator')->get('lang.number'); ?>" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone">
                                            </div> 
                                        </div>

                                        <div class="form-group col-12">
                                            <div class="relative__group">
                                                <label for="" class="abs__label"><?php echo app('translator')->get('lang.city'); ?></label>
                                                <input type="text" placeholder="<?php echo app('translator')->get('lang.city'); ?>" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city">
                                            </div> 
                                        </div>

                                        <div class="form-group col-12">
                                            <div class="relative__group">
                                                <label for="" class="abs__label"><?php echo app('translator')->get('lang.age'); ?></label>
                                                <input type="number" placeholder="<?php echo app('translator')->get('lang.age'); ?>" class="form-control <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="age">
                                            </div> 
                                        </div>
                                        <div class="relative__group">
                                            <label for="" class="before__label"><?php echo app('translator')->get('lang.type'); ?></label>
                                            <label class="type__label">
                                                <input type="radio" name="type" value="male">
                                                <span><?php echo app('translator')->get('lang.male'); ?></span>
                                            </label>
                                            <label class="type__label">
                                                <input type="radio" name="type" value="female">
                                                <span><?php echo app('translator')->get('lang.female'); ?></span>
                                            </label>
                                            <span class="text-danger"> <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                        </div>
                                        <button type="submit" href="#" class="modal__btn next__btn"><?php echo app('translator')->get('lang.next'); ?></button>
                                    </div>
                                    <div class="col-12 col-md-6 align__items">
                                        <div class="file__group mb__44">
                                            <input type="file" class="lg__control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image">
                                            <span><?php echo app('translator')->get('lang.Please add your photo'); ?></span>
                                            <img src="<?php echo e(asset('images/user2.png')); ?>" class="icon__user">
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="cv__group">
                                            <span><?php echo app('translator')->get('lang.attach cv'); ?></span>
                                            <input type="file" class="sm__control <?php $__errorArgs = ['file_job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="file_job">
                                            <img src="<?php echo e(asset('images/upload.png')); ?>" alt="" class="upload__img">
                                            <?php $__errorArgs = ['file_job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="relative__textarea">
                                            <textarea class="jobs__textarea" placeholder="<?php echo app('translator')->get('lang.Your Features'); ?>" maxlength="100" name="notes"></textarea>
                                            <div class="abs__value">
                                                <span class="number__increase">0</span> / <span>100</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="coll__orders tab-pane fade" role="tabpanel" id="coll__orders">
                        <form action="<?php echo e(route('jobs.storetraining')); ?>" method="post" enctype="multipart/form-data" class="register__form jobs__from pt__70">
                            <?php echo csrf_field(); ?>
                                <div class="d__flex">
                                    <div class="col-12 col-md-6">
                                        <select class="nice-select dashboard__select" id="dashboard__select" name="job_name">
                                            <option value="sales"><?php echo app('translator')->get('lang.sales'); ?></option>
                                            <option value="cook"><?php echo app('translator')->get('lang.cook'); ?></option>
                                            <option value="accountant" selected><?php echo app('translator')->get('lang.accountant'); ?></option>
                                            <option value="marketing"><?php echo app('translator')->get('lang.marketing'); ?></option>
                                        </select>
                                        <div class="relative__group option__none">
                                            <label class="type__label">
                                                <input type="radio" name="work_from" value="work office" class="<?php $__errorArgs = ['work_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <span><?php echo app('translator')->get('lang.work office'); ?></span>
                                            </label>
                                            <label class="type__label">
                                                <input type="radio" name="work_from" value="work from home" class="<?php $__errorArgs = ['work_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <span><?php echo app('translator')->get('lang.work from home'); ?></span>
                                            </label>
                                        </div>
                                        <div class="form-group col-12">
                                            <div class="relative__group">
                                                <label for="" class="abs__label"><?php echo app('translator')->get('lang.name'); ?></label>
                                                <input type="text" placeholder="<?php echo app('translator')->get('lang.name'); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name">
                                                <span class="text-danger"> <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                            </div> 
                                        </div>

                                        <div class="form-group col-12">
                                            <div class="relative__group">
                                                <label for="" class="abs__label"><?php echo app('translator')->get('lang.email'); ?></label>
                                                <input type="email" placeholder="<?php echo app('translator')->get('lang.email'); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email">
                                                <span class="text-danger"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                            </div> 
                                        </div>

                                        <div class="form-group col-12">
                                            <div class="relative__group">
                                                <label for="" class="abs__label"><?php echo app('translator')->get('lang.number'); ?></label>
                                                <input type="phone" placeholder="<?php echo app('translator')->get('lang.number'); ?>" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone">
                                            <span class="text-danger"> <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                            </div> 
                                        </div>

                                        <div class="form-group col-12">
                                            <div class="relative__group">
                                                <label for="" class="abs__label"><?php echo app('translator')->get('lang.city'); ?></label>
                                                <input type="text" placeholder="<?php echo app('translator')->get('lang.city'); ?>" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city">
                                            <span class="text-danger"> <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                            </div> 
                                        </div>

                                        <div class="form-group col-12">
                                            <div class="relative__group">
                                                <label for="" class="abs__label"><?php echo app('translator')->get('lang.age'); ?></label>
                                                <input type="text" placeholder="<?php echo app('translator')->get('lang.age'); ?>" class="form-control <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="age">
                                            <span class="text-danger"> <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                            </div> 
                                        </div>
                                        <div class="relative__group">
                                            <label for="" class="before__label"><?php echo app('translator')->get('lang.type'); ?></label>
                                            <label class="type__label">
                                                <input type="radio" name="type" value="male">
                                                <span><?php echo app('translator')->get('lang.male'); ?></span>
                                            </label>
                                            <label class="type__label">
                                                <input type="radio" name="type" value="female">
                                                <span><?php echo app('translator')->get('lang.female'); ?></span>
                                            </label>
                                        </div>
                                        <button type="submit" href="#" class="modal__btn next__btn"><?php echo app('translator')->get('lang.next'); ?></button>
                                    </div>
                                    <div class="col-12 col-md-6 align__items">
                                        <div class="file__group mb__44">
                                            <input type="file" class="lg__control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image">
                                            <span><?php echo app('translator')->get('lang.Please add your photo'); ?></span>
                                            <img src="<?php echo e(asset('images/user2.png')); ?>" class="icon__user">
                                            <span class="text-danger"> <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                        </div>
                                        <div class="cv__group">
                                            <span><?php echo app('translator')->get('lang.attach cv'); ?></span>
                                            <input type="file" class="sm__control <?php $__errorArgs = ['file_job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="file_job">
                                            <img src="<?php echo e(asset('images/upload.png')); ?>" alt="" class="upload__img">
                                            <span class="text-danger"> <?php $__errorArgs = ['file_job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                        </div>
                                        <div class="relative__textarea">
                                            <textarea class="jobs__textarea" placeholder="<?php echo app('translator')->get('lang.Your Features'); ?>" maxlength="100" name="notes"></textarea>
                                            <div class="abs__value">
                                                <span class="number__increase">0</span> / <span>100</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="contact__info p__absolute">
            <h3 class="contact__title"><?php echo app('translator')->get('lang.contact info'); ?></h3>
            <div class="contact__card">
                <span class="phone_icon info__icon"></span>
                <a href="#" class="info__num">0000 000 000 000</a>
            </div>
            <div class="contact__card">
                <span class="email_icon info__icon"></span>
                <a href="#" class="info__num">example@gmail.com</a>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cloudchef\resources\views/jobs.blade.php ENDPATH**/ ?>