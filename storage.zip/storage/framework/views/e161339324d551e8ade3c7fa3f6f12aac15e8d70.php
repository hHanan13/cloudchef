
<!doctype html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cloud Chef</title>
    <link href="<?php echo e(asset('/images/logo.png')); ?>" rel="icon" type="image/png" sizes="16x16">
    <link href="<?php echo e(asset('/css/animate.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/css/nice-select.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/css/datepicker.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/css/hover.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/media.css')); ?>" rel="stylesheet">
    <?php if(app()->getLocale()=='en'): ?>
    <link href="<?php echo e(asset('/css/style-en.css')); ?>" rel="stylesheet">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php if(app()->getLocale()=='ar'): ?>
  
  <link href="<?php echo e(asset('/css/style-ar.css')); ?>" rel="stylesheet">
<?php endif; ?>
 
</head>
<body class="home-page">
     <!--loader-->
     <div class="loader-container" id="loader-container">
        <div class="loader">
            <div class="bounce-one"></div>
            <div class="bounce-two"></div>
        </div>
     </div>
    
     <div class="login__wrapper__page">
<!-- 
     <?php if(App::getLocale() == 'ar'): ?>
                   <a href="<?php echo e(url('/en/'.request()->segment(3))); ?>" class="lang__link">En</a>
            <?php else: ?>
                  <a href="<?php echo e(url('/ar/'.request()->segment(3))); ?>" class="lang__link">ar</a>
            <?php endif; ?> -->

        <div class="login__card">
            <form method="POST" action="<?php echo e(route('login')); ?>" class="register__form">
                <?php echo csrf_field(); ?>
                <a href="<?php echo e(url('/')); ?>" class="login__logo">
                    <img src="<?php echo e(asset('/images/logo.png')); ?>" alt="">
                </a>
                <h3 class="login__title"><?php echo app('translator')->get('lang.welcome'); ?>...</h3>
                <input type="email" placeholder="<?php echo app('translator')->get('lang.email'); ?>" name="email" class="form-control" id="username">
                <input type="password" placeholder="<?php echo app('translator')->get('lang.password'); ?>" name="password" class="form-control" id="password">
                <button type="submit" class="login__btn"><?php echo app('translator')->get('lang.login'); ?></button>
            </form>
        </div>
     </div>

</body>
<script src="<?php echo e(asset('/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/jquery.nice-select.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/datepicker.js')); ?>"></script>
    <script>
      new WOW().init(); 
    </script>

        <?php if(app()->getLocale()=='ar'): ?>
        <script
                src="https://cdn.rtlcss.com/bootstrap/3.3.7/js/bootstrap.min.css"
                integrity="sha384-B4D+9otHJ5PJZQbqWyDHJc6z6st5fX3r680CYa0Em9AUG6jqu5t473Y+1CTZQWZv"
            crossorigin="anonymous">
            </script>
        <?php endif; ?>

</html><?php /**PATH C:\xampp\htdocs\cloudchef\resources\views/auth/login.blade.php ENDPATH**/ ?>