

<?php $__env->startSection('content'); ?>
<div class="container">
<table>
<thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">name</th>
      <th scope="col">email</th>
      <th scope="col">amount</th>
      <th scope="col">action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e(++$key); ?></th>
      <td><?php echo e($value->name); ?></td>
      <td><?php echo e($value->email); ?></td>
      <td><?php echo e($value->amount); ?></td>
      <th><a href="<?php echo e(route('payment.refund',$value->tran_id)); ?>" class="btn">refund</a></th>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cloudchef\resources\views/table.blade.php ENDPATH**/ ?>